package guest;

public class Guest {
	private int guestNum;
	private String guestTitle;
	private String guestDate;
	private String guestContent;
	private Boolean guestFlag;
	private String guestPass;
	
	public int getguestNum() {
		return guestNum;
	}
	public void setguestNum(int guestNum) {
		this.guestNum = guestNum;
	}
	public String getguestTitle() {
		return guestTitle;
	}
	public void setguestTitle(String guestTitle) {
		this.guestTitle = guestTitle;
	}
	public String getguestDate() {
		return guestDate;
	}
	public void setguestDate(String guestDate) {
		this.guestDate = guestDate;
	}
	public String getguestContent() {
		return guestContent;
	}
	public void setguestContent(String guestContent) {
		this.guestContent = guestContent;
	}
	public Boolean getguestFlag() {
		return guestFlag;
	}
	public void setguestFlag(Boolean guestFlag) {
		this.guestFlag = guestFlag;
	}
	public String getguestPass() {
		return guestPass;
	}
	public void setguestPass(String guestPass) {
		this.guestPass = guestPass;
	}
	
}
