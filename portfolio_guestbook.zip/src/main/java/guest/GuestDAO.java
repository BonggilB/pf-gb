package guest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.DriverManager;
//import java.util.ArrayList;

public class GuestDAO {
	
	private Connection conn;
	private ResultSet rs;
	private PreparedStatement pstmt;
	
	public GuestDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/guestbook";
			String dbID = "guest";
			String dbPassword = "guest1@#";
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection(dbURL,dbID,dbPassword);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	//날짜 구하기
	public String getDate() {
		String SQL = "SELECT DATE(NOW())";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}			
		}catch (Exception e) {
			e.printStackTrace();
			
		}
		return "";
	}
	//목록 내용 불러오기
	public ArrayList<Guest> getguestbook() {
		String SQL = "SELECT * FROM guestbook ORDER BY guestNum";
		ArrayList<Guest> list = new ArrayList<Guest>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Guest guest=new Guest();
				guest.setguestNum(rs.getInt(1));
				guest.setguestTitle(rs.getString(2));
				guest.setguestDate(rs.getString(3));
				guest.setguestContent(rs.getString(4));
				list.add(guest);
			}
		}catch (Exception e) {
			e.printStackTrace();			
		}
		return list;
	}
	//목록 내용 함수.................나중에 jsp완성되면 자바 사용하여 list.get().getguest(해당함수)사용하여 내용표시
	public Guest getguest(int guestNum) {
		String SQL = "SELECT * FROM guestbook WHERE guestNum=? ORDER BY guestNum DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, guestNum);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Guest guest=new Guest();
				guest.setguestNum(rs.getInt(1));
				guest.setguestTitle(rs.getString(2));
				guest.setguestContent(rs.getString(3));				
				return guest;
			}
		}catch (Exception e) {
			e.printStackTrace();			
		}
		return null;
	}
	//목록불러오기
	public int nextguestNum() {
		String SQL = "SELECT guestNum FROM guestbook ORDER BY guestNum ASC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);			
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;	
			}else {
				return 1;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	return -1;
	}
	//작성
	public int guestWrite(String guestTitle,String guestContent,String guestPass) {
		String SQL = "insert into guestbook(guestTitle,guestContent,guestDate,guestFlag,guestPass) values(?,?,?,?,?);";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setString(1, guestTitle);
			pstmt.setString(2, guestContent);
			pstmt.setString(3, getDate());
			pstmt.setInt(4, 1);
			pstmt.setString(5, guestPass);
			return pstmt.executeUpdate();			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	//삭제
	public int delete(int guestNum) {
		String SQL = "DELETE FROM guestbook WHERE guestNum=?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, guestNum);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
}
